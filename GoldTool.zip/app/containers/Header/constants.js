/*
 *
 * Header constants
 *
 */

export const DEFAULT_ACTION = 'app/Header/DEFAULT_ACTION';
export const INFLATION_VALUE = 'app/Header/INFLATION_VALUE';
