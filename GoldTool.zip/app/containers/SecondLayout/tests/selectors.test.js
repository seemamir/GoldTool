// import { fromJS } from 'immutable';
// import { selectSecondLayoutDomain } from '../selectors';

describe('selectSecondLayoutDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
