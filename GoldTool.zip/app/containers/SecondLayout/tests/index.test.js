// import React from 'react';
// import { shallow } from 'enzyme';

// import { SecondLayout } from '../index';

describe('<SecondLayout />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
