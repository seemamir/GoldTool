/*
 *
 * SecondLayout constants
 *
 */

export const DEFAULT_ACTION = 'app/SecondLayout/DEFAULT_ACTION';
