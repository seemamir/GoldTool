/*
 *
 * ThirdLayout constants
 *
 */

export const DEFAULT_ACTION = 'app/ThirdLayout/DEFAULT_ACTION';
