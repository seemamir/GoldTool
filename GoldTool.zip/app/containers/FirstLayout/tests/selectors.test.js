// import { fromJS } from 'immutable';
// import { selectFirstLayoutDomain } from '../selectors';

describe('selectFirstLayoutDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
