/*
 *
 * FirstLayout constants
 *
 */

export const DEFAULT_ACTION = 'app/FirstLayout/DEFAULT_ACTION';
