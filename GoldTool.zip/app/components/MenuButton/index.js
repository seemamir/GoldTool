/**
 *
 * Button
 *
 */

import React from 'react';
// import { Button } from 'antd';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

/* eslint-disable react/prefer-stateless-function */
class MenuButton extends React.Component {
  render() {
    return (
      <div>{/* <Button type="primary" onClick={this.handleClick} /> */}</div>
    );
  }
}

MenuButton.propTypes = {};

export default MenuButton;
