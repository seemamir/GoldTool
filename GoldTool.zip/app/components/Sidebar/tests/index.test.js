// import React from 'react';
// import { shallow } from 'enzyme';

// import SideBar from '../index';

describe('<SideBar />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
