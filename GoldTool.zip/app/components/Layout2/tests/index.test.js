// import React from 'react';
// import { shallow } from 'enzyme';

// import Layout1 from '../index';

describe('<Layout1 />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
